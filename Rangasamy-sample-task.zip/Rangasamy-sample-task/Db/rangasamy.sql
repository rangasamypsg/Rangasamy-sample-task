-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2016 at 08:00 PM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rangasamy`
--

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=113 ;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `created`, `modified`) VALUES
(1, 'Chennai', '2016-01-11 13:36:40', '2016-07-22 03:26:51'),
(2, 'Coimbatore', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(3, 'Madurai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(4, 'Tiruchirappalli', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(5, 'Salem', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(6, 'Tirunelveli', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(7, 'Tiruppur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(8, 'Ranipet', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(9, 'Nagercoil', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(10, 'Thanjavur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(11, 'Vellore', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(12, 'Kancheepuram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(13, 'Erode', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(14, 'Tiruvannamalai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(15, 'Pollachi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(16, 'Rajapalayam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(17, 'Sivakasi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(18, 'Pudukkottai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(19, 'Neyveli (TS)', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(20, 'Nagapattinam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(21, 'Viluppuram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(22, 'Tiruchengode', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(23, 'Vaniyambadi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(24, 'Theni Allinagaram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(25, 'Udhagamandalam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(26, 'Aruppukkottai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(27, 'Paramakudi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(28, 'Arakkonam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(29, 'Virudhachalam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(30, 'Srivilliputhur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(31, 'Tindivanam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(32, 'Virudhunagar', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(33, 'Karur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(34, 'Valparai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(35, 'Sankarankovil', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(36, 'Tenkasi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(37, 'Palani', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(38, 'Pattukkottai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(39, 'Tirupathur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(40, 'Ramanathapuram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(41, 'Udumalaipettai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(42, 'Gobichettipalayam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(43, 'Thiruvarur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(44, 'Thiruvallur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(45, 'Panruti', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(46, 'Namakkal', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(47, 'Thirumangalam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(48, 'Vikramasingapuram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(49, 'Nellikuppam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(50, 'Rasipuram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(51, 'Tiruttani', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(52, 'Nandivaram-Guduvancheri', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(53, 'Periyakulam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(54, 'Pernampattu', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(55, 'Vellakoil', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(56, 'Sivaganga', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(57, 'Vadalur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(58, 'Rameshwaram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(59, 'Tiruvethipuram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(60, 'Perambalur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(61, 'Usilampatti', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(62, 'Vedaranyam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(63, 'Sathyamangalam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(64, 'Puliyankudi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(65, 'Nanjikottai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(66, 'Thuraiyur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(67, 'Sirkali', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(68, 'Tiruchendur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(69, 'Periyasemur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(70, 'Sattur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(71, 'Vandavasi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(72, 'Tharamangalam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(73, 'Tirukkoyilur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(74, 'Oddanchatram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(75, 'Palladam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(76, 'Vadakkuvalliyur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(77, 'Tirukalukundram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(78, 'Uthamapalayam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(79, 'Surandai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(80, 'Sankari', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(81, 'Shenkottai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(82, 'Vadipatti', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(83, 'Sholingur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(84, 'Tirupathur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(85, 'Manachanallur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(86, 'Viswanatham', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(87, 'Polur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(88, 'Panagudi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(89, 'Uthiramerur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(90, 'Thiruthuraipoondi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(91, 'Pallapatti', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(92, 'Ponneri', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(93, 'Lalgudi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(94, 'Natham', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(95, 'Unnamalaikadai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(96, 'P.N.Patti', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(97, 'Tharangambadi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(98, 'Tittakudi', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(99, 'Pacode', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(100, 'O'' Valley', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(101, 'Suriyampalayam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(102, 'Sholavandan', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(103, 'Thammampatti', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(104, 'Namagiripettai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(105, 'Peravurani', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(106, 'Parangipettai', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(107, 'Pudupattinam', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(108, 'Pallikonda', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(109, 'Sivagiri', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(110, 'Punjaipugalur', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(111, 'Padmanabhapuram', '2016-01-11 13:36:40', '2016-07-21 15:36:40'),
(112, 'Thirupuvanam', '2016-01-11 13:36:40', '2016-07-21 15:36:40');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created`, `modified`) VALUES
(1, 'India', '2016-01-11 08:06:40', '2016-07-24 14:22:15');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
`id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `created` timestamp NULL DEFAULT NULL,
  `modified` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `created`, `modified`) VALUES
(1, 'Tamil nadu', '2016-01-11 08:06:40', '2016-07-24 14:22:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `gender` tinyint(3) NOT NULL,
  `address` text NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url` varchar(250) NOT NULL,
  `country_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `zipcode` varchar(6) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `con_password` varchar(50) NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `gender`, `address`, `mobile_no`, `email`, `url`, `country_id`, `state_id`, `city_id`, `zipcode`, `username`, `password`, `con_password`, `status`, `created`, `modified`) VALUES
(1, 'Rangasamy', 'Murugan', 0, '26,bharathi nagar,near amman temple,north street,coimbatore', '9789679789', 'rangasamy@gmail.com', 'http://www.w3schools.com/php/php_form_url_email.asp', 1, 1, 2, '641022', 'rangasamy', 'ad09e3d1804ca8a23bafed47e583b773b01f6a71', 'ad09e3d1804ca8a23bafed47e583b773b01f6a71', 1, '2016-07-24 16:07:19', '2016-07-24 19:46:03'),
(2, 'Krishna', 'kumar', 0, '63,Periyar Nagar,West street,coimbatore', '9769786987', 'krishnan@gmail.com', 'http://codekarate.com/blog/validating-url-php', 1, 1, 2, '641022', 'krishnan', '6e0d2772830ff39196ce11b17be790d59bb907a2', '6e0d2772830ff39196ce11b17be790d59bb907a2', 1, '2016-07-24 17:50:40', '2016-07-24 19:47:14'),
(3, 'Siddarth', 'anand', 0, '79,Chinnaswamy road,south street,coimbatore', '9786987987', 'siddarth@gmail.com', 'http://myphpform.com/validating-url-email.php', 1, 1, 15, '645363', 'siddarth', '2706347775c63120879392f431eadeb79e7caff8', '2706347775c63120879392f431eadeb79e7caff8', 1, '2016-07-24 19:51:24', '2016-07-24 19:57:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
